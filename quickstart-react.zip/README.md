### Install Dependencies

`yarn`

### Add Your Vapi Public Key

Open `src/App.jsx` and replace the placeholder public key with your own:

### Start

`yarn start`